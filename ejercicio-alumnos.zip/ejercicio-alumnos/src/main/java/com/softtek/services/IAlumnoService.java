package com.softtek.services;

import java.util.List;

import com.softtek.entity.Alumno;

public interface IAlumnoService {
	
	public List<Alumno> consultarTodos();
	public Alumno buscar(Long numAlumno);

}
