package com.softtek.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.softtek.entity.Alumno;

@RepositoryRestResource(collectionResourceRel = "alumnos", path = "alumnos")
public interface AlumnosDAO extends CrudRepository<Alumno, Long>{

}
