package com.softtek.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.entity.Alumno;
import com.softtek.services.IAlumnoService;

@RestController
public class AlumnoController {
	
	@Autowired
	private IAlumnoService alumnoService;
	
	@Value("${server.port}")
	private Integer port;
	
	// localhost:8001/todos
	@GetMapping("/todos")
	public List<Alumno> listar(){
		return alumnoService.consultarTodos()
				.stream()
				.map(alum -> {
					alum.setPort(port);
					return alum;
				}).collect(Collectors.toList());
	}
	
	
	// localhost:8001/buscar/3
	@GetMapping("/buscar/{numAlumno}")
	public Alumno buscar(@PathVariable Long numAlumno) {
		Alumno alumno = alumnoService.buscar(numAlumno);
		alumno.setPort(port);
		return alumno;
	}

}
