package com.softtek.persistence;

import java.util.List;


import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@RepositoryRestResource(collectionResourceRel = "productos", path="productos")
public interface ProductoDAO extends CrudRepository<Producto, Long>, CustomProductoRepository{
	
	
	// Sobreescribir el metodo save para trabajar con transacciones
	@Override
	@Transactional(propagation = Propagation.REQUIRED,
				   isolation = Isolation.SERIALIZABLE,
				   rollbackFor = Exception.class)
	<S extends Producto> S save(S entity);
	
	
	
	

	// Mostrar todos los productos de la tabla
	// http://localhost:8080/productos
	
	// Podemos utilizar los metodos de CrudRepository
	// http://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// Nos podemos crear nuestros propios metodos utilizando las palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	// http://localhost:8080/productos/search/findByDescripcion?descripcion=Raton
	public List<Producto> findByDescripcion(@Param("descripcion") String descripcion);
	
	// http://localhost:8080/productos/search/findByPrecioOrderByDescripcionDesc?precio=50
	public List<Producto> findByPrecioOrderByDescripcionDesc(@Param("precio") double precio);
	
	// http://localhost:8080/productos/search/findByPrecioGreaterThanEqual?precio=100
	public List<Producto> findByPrecioGreaterThanEqual(@Param("precio") double precio);
	
	// http://localhost:8080/productos/search/findByPrecioBetween?minimo=50&maximo=200
	public List<Producto> findByPrecioBetween(@Param("minimo") double minimo, @Param("maximo") double maximo);
	
	// Aqui se ven todos los metodos personalizados creados
	// http://localhost:8080/productos/search
	
}
