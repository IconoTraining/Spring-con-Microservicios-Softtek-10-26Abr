package com.softtek.persistence;

import java.util.List;


public interface CustomProductoRepository {
	
	// http://localhost:8080/productos/search/OrderByDescripcionDesc
	public List<Producto> OrderByDescripcionDesc();
		


}
