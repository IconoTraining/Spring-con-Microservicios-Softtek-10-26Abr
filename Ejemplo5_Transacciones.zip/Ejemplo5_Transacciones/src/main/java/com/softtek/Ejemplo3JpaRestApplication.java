package com.softtek;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo3JpaRestApplication implements CommandLineRunner{
	
	@Autowired
	public ProductoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		List<Producto> lista = new ArrayList<>();
		lista.add(new Producto(1L, "Proyector", 700));
		lista.add(new Producto(2L, "Monitor", 150));
		lista.add(new Producto(3L, "Raton", 50));
		
		// Modifica el producto con id 1L
		lista.add(new Producto(1L, "Pizarra digital", 700));
		
		// Genera error al no tener PK
		lista.add(new Producto());
		
		try {
			insertar(lista);
		} catch(Exception ex) {
			System.out.println("Se ha producido un error");
		}
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
			   isolation = Isolation.SERIALIZABLE,
			   rollbackFor = Exception.class)
	public void insertar(List<Producto> productos) throws Exception {
		/*for (Producto producto : productos) {
			// Lo trata como transaccion independiente por cada producto
			dao.save(producto);
		}*/
		
		// Para que me genere excepcion y haya rollback
		dao.saveAll(productos);
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3JpaRestApplication.class, args);
	}

}
