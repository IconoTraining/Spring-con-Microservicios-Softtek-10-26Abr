package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo3JpaRestApplication implements CommandLineRunner{
	
	@Autowired
	public ProductoDAO dao;

	@Override
	public void run(String... args) throws Exception {
		insertar(
					new Producto(1L, "Proyector", 700),
					new Producto(2L, "Monitor", 150),
					new Producto(3L, "Raton", 50),
					new Producto(1L, "Proyector", 700)
		);
		
	}
	
	@Transactional(propagation = Propagation.REQUIRED,
			   isolation = Isolation.SERIALIZABLE,
			   rollbackFor = Exception.class)
	public void insertar(Producto... productos) {
		for (Producto producto : productos) {
			dao.save(producto);
		}
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo3JpaRestApplication.class, args);
	}

}
