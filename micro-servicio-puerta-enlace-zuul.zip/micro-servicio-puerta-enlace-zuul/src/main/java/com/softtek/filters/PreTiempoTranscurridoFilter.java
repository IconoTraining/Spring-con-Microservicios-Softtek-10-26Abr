package com.softtek.filters;

import org.springframework.stereotype.Component;

import com.netflix.zuul.ZuulFilter;
import com.netflix.zuul.context.RequestContext;
import com.netflix.zuul.exception.ZuulException;

@Component
public class PreTiempoTranscurridoFilter extends ZuulFilter{

	@Override
	public boolean shouldFilter() {
		// Habilitar o deshabilitar el filtro
		// Si devuelve true se ejecuta el metodo run()
		// Si devuelve false no se ejecuta
		return true;
	}

	@Override
	public Object run() throws ZuulException {
		// Aqui se resuelve la logica de negocio
		// Aqui mediremos el tiempo de inicio de la peticion
		
		// Tomar el tiempo de inicio
		Long tiempoInicio = System.currentTimeMillis();
		
		
		// Lo guardo como atributo de peticion
		RequestContext ctx = RequestContext.getCurrentContext();
		ctx.getRequest().setAttribute("tiempoInicio", tiempoInicio);
		
		return null;
	}

	@Override
	public String filterType() {
		// Hay 3 tipos de filtro: pre, post, route
		//  - pre: se ejecuta antes de que el request sea enrutado.
		//         Se usa para pasar datos al request
		//  - post: se ejecuta despues del request
		//          Se usa para modificar la respuesta
		//  - route: se ejecuta durante el enrutado de request, aqui se resuelve la ruta
		//           Se usa para la comunicacion con el microservicio
		
		return "pre";
	}

	@Override
	public int filterOrder() {
		// Si hay varios filtros elegimos el orden de ejecución
		return 0;
	}

}
