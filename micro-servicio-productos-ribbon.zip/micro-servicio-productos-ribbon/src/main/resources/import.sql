insert into productos (DESCRIPCION, PRECIO) values ('Monitor', 195.90);
insert into productos (DESCRIPCION, PRECIO) values ('Teclado', 50);
insert into productos (DESCRIPCION, PRECIO) values ('Raton', 50);
insert into productos (DESCRIPCION, PRECIO) values ('Impresora', 50);
insert into productos (DESCRIPCION, PRECIO) values ('Scanner', 347.50);