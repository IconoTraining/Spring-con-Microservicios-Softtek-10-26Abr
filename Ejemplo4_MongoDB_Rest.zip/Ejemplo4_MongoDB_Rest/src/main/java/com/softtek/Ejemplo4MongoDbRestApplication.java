package com.softtek;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.softtek.persistence.Producto;
import com.softtek.persistence.ProductoDAO;

@SpringBootApplication
public class Ejemplo4MongoDbRestApplication implements CommandLineRunner{
	
	// Inyectar una instancia del DAO
	@Autowired
	private ProductoDAO dao;

	
	@Override
	public void run(String... args) throws Exception {
		
		// Borrar todos los datos
		dao.deleteAll();
		
		// Alta de productos
		dao.save(new Producto("Monitor", 139.5));
		dao.save(new Producto("Pizarra digital", 500));
		dao.save(new Producto("Raton", 50));
		dao.save(new Producto("Teclado", 50));
		
		// Mostrar todos los productos
		System.out.println("Todos los productos");
		System.out.println("-------------------");
		for(Producto p  : dao.findAll()) {
			System.out.println(p);
		}
		
		// Buscar un producto por su id
		System.out.println("Buscar por id: " + dao.findById("6436d7d3cc37fb6440ee0801"));
		
		// Mostrar todos los productos ordenados por descripcion
		System.out.println("Todos los productos ordenados por descripcion");
		System.out.println("---------------------------------------------");
		for(Producto p  : dao.OrderByDescripcion()) {
			System.out.println(p);
		}
		
		// Mostrar todos los productos que cuesten 50€ ordenados por descripcion descendente
		System.out.println("Todos los productos ordenados por descripcion descendente");
		System.out.println("---------------------------------------------------------");
		for(Producto p  : dao.findByPrecioOrderByDescripcionDesc(50)) {
			System.out.println(p);
		}
		
	}
	
	public static void main(String[] args) {
		SpringApplication.run(Ejemplo4MongoDbRestApplication.class, args);
	}

}
