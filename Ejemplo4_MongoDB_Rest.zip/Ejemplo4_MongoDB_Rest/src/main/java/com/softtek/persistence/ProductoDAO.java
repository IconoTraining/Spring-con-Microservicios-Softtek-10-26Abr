package com.softtek.persistence;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductoDAO extends MongoRepository<Producto, String>{
	
	// http://localhost:8080/productos
	
	// Podemos utilizar los metodos heredados de MongoRepository
	// http://docs.spring.io/spring-data/jpa/docs/current/reference/html/
	
	// o crear los nuestros propios utilizando las palabras clave
	// https://docs.spring.io/spring-data/jpa/docs/current/reference/html/#repository-query-keywords
	
	// http://localhost:8080/productos/search/OrderByDescripcion
	public List<Producto> OrderByDescripcion();
	
	// http://localhost:8080/productos/search/findByPrecioOrderByDescripcionDesc?precio=50
	public List<Producto> findByPrecioOrderByDescripcionDesc(@Param("precio") double precio);

}
