package com.softtek.models;

import java.util.List;

public class Colegio {
	
	private List<Alumno> alumnos;
	
	public Colegio() {
		// TODO Auto-generated constructor stub
	}

	public Colegio(List<Alumno> alumnos) {
		super();
		this.alumnos = alumnos;
	}

	public List<Alumno> getAlumnos() {
		return alumnos;
	}

	public void setAlumnos(List<Alumno> alumnos) {
		this.alumnos = alumnos;
	}

	@Override
	public String toString() {
		return "Colegio [alumnos=" + alumnos + "]";
	}
	
	

}
