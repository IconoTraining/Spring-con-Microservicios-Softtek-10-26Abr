package com.softtek.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.clients.ColegioClienteRest;
import com.softtek.models.Alumno;

@Service("serviceFeign")
public class ColegioServiceFeign implements ColegioService{
	
	@Autowired
	private ColegioClienteRest clienteFeign;

	@Override
	public List<Alumno> todos() {
		return clienteFeign.listar();
	}

	@Override
	public Alumno buscar(Long numAlumno) {
		return clienteFeign.buscar(numAlumno);
	}

}
