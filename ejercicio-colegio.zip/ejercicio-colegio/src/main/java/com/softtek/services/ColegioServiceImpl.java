package com.softtek.services;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.softtek.models.Alumno;

@Service("serviceRestTemplate")
public class ColegioServiceImpl implements ColegioService{
	
	@Autowired
	private RestTemplate clienteRest;

	@Override
	public List<Alumno> todos() {
		List<Alumno> alumnos = Arrays.asList(clienteRest.getForObject(
				"http://servicio-alumnos/todos", Alumno[].class));
		return alumnos;
	}

	@Override
	public Alumno buscar(Long numAlumno) {
		Map<String, String> pathVariables = new HashMap<>();
		pathVariables.put("numAlumno", numAlumno.toString());
		Alumno alumno = clienteRest.getForObject(
				"http://servicio-alumnos/buscar/{numAlumno}", 
				Alumno.class, pathVariables);
		return alumno;
	}

}
