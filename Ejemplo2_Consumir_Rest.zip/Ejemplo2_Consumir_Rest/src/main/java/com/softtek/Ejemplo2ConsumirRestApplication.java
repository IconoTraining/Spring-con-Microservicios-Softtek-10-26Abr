package com.softtek;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class Ejemplo2ConsumirRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejemplo2ConsumirRestApplication.class, args);
	}
	
	// Inyectar RestTemplate
	@Bean
	public RestTemplate restTemplate(RestTemplateBuilder builder) {
		return builder.build();
	}
	
	@Bean
	public CommandLineRunner run(RestTemplate restTemplate) {
		return datos -> {
			String mensaje = restTemplate.getForObject(
					"http://localhost:8080/despedir?usuario=Anabel", String.class);
			System.out.println(mensaje);
		};
	}

}
