package com.softtek.clients;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.softtek.models.Item;

@FeignClient(name = "service-item")
public interface ItemClienteRest {

	
	@GetMapping("/listar")
	public List<Item> listar();
	
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item detalle(@PathVariable Long id, @PathVariable Integer cantidad);
}
