package com.softtek.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.clients.ItemClienteRest;
import com.softtek.models.Carrito;
import com.softtek.models.Item;
import com.softtek.persistence.CarritoDAO;

@Service
public class CarritoServiceImpl implements CarritoService{
	
	@Autowired
	private CarritoDAO dao;
	
	@Autowired
	private ItemClienteRest clienteFeign;
	

	@Override
	public Carrito crear(String usuario) {
		return dao.save(new Carrito(usuario, new ArrayList<>(), 0));
	}

	@Override
	public void agregarItem(Long id, Integer cantidad, String usuario) {
		Carrito carrito = buscar(usuario);
		Item item = clienteFeign.detalle(id, cantidad);
		carrito.getContenido().add(item);
		double importe = item.getProducto().getPrecio() * item.getCantidad();
		carrito.setImporte(carrito.getImporte() + importe);
		dao.save(carrito);
	}

	@Override
	public Carrito buscar(String usuario) {
		return dao.findByUsuario(usuario);
	}

	@Override
	public void eliminarItem(Long id, String usuario) {
		Carrito carrito = buscar(usuario);
		List<Item> contenido = carrito.getContenido();
		Item encontrado = null;
		for (Item item : contenido) {
			if (id == item.getProducto().getID()) {
				encontrado = item;
				break;
			}
		}
		contenido.remove(encontrado);
		double importe = encontrado.getProducto().getPrecio() * encontrado.getCantidad();
		carrito.setImporte(carrito.getImporte() - importe);
		dao.save(carrito);
	}

}









