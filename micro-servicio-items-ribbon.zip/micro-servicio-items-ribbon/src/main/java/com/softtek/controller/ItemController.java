package com.softtek.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.Item;
import com.softtek.services.ItemService;

@RestController
public class ItemController {
	
	@Autowired
	// Otra forma de solucionar ambiguedades cuando vamos a inyectar un bean
	// y hay mas de uno es poner el nombre del bean con @Qualifier
	//@Qualifier("serviceFeign")
	@Qualifier("serviceRestTemplate")
	private ItemService itemService;
	
	// localhost:8002/listar
	@GetMapping("/listar")
	public List<Item> listar(){
		return itemService.findAll();
	}
	
	// localhost:8002/ver/2/cantidad/5
	@GetMapping("/ver/{id}/cantidad/{cantidad}")
	public Item detalle(@PathVariable Long id, @PathVariable Integer cantidad) {
		return itemService.findById(id, cantidad);
	}

}
