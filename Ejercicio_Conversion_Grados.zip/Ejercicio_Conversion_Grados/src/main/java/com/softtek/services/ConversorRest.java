package com.softtek.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ConversorRest {
	
	// http://localhost:8080/fahrenheit?grados=37.5
	@RequestMapping("/fahrenheit")
	public double gradosAFahrenheit(@RequestParam(value="grados") double grados) {
		 return (grados * 9/5) + 32;

	}
	
	// http://localhost:8080/grados?fahrenheit=99.5
	@RequestMapping("/grados")
	public double fahrenheitAGrados(@RequestParam(value="fahrenheit")double fahrenheit) {
		return (fahrenheit - 32) * 5/9;
	}

}
