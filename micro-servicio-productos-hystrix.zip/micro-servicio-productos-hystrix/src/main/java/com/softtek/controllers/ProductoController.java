package com.softtek.controllers;

import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.softtek.models.entity.Producto;
import com.softtek.services.IProductoService;

@RestController
public class ProductoController {
	
	@Autowired
	private IProductoService productoService;
	
	// Al ser puerto dinamico, esta propiedad NO FUNCIONA
	@Value("${server.port}")
	private Integer port;
	
	// SOLUCION:
	@Autowired
	private HttpServletRequest request;
	
	// localhost:8001/listar
	@GetMapping("/listar")
	public List<Producto> listar(){
		return productoService.findAll()
				.stream()
				.map(p -> {
					//p.setPort(port);
					p.setPort(request.getLocalPort());
					return p;
				})
				.collect(Collectors.toList());
	}
	
	
	// localhost:8001/ver/2
	@GetMapping("/ver/{id}")
	public Producto buscar(@PathVariable Long id) throws InterruptedException {
		Producto p = productoService.findById(id);
		//p.setPort(port);
		p.setPort(request.getLocalPort());
		
		
		// Provocar una excepcion que llegara al servicio de items
		//if (id > 4) throw new RuntimeException("Error al buscar el producto");
		
		
		// Por defecto, los microservicios esperan un maximo de 1 segundo en obtener la respuesta
		// Si la peticion supera ese segundo devuelve un timeout.
		// Vamos a provocar un Timeout parando la ejecucion 10 segundos
		//Thread.sleep(10000);
		
		
		return p;
	}

}










