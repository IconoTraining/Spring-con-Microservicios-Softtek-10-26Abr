package com.softtek.services;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SaludoRest {
	
	// http://localhost:8080/saludo
	@RequestMapping("/saludo")
	public String saludar() {
		return  "Bienvenidos al curso de Microservicios";
	}
	
	// http://localhost:8080/despedir?usuario=Anabel
	@RequestMapping("/despedir")
	public String adios(@RequestParam(value="usuario") String nombre) {
		return "Hasta luego " + nombre + " !!!!";
	}

}
