package com.softtek.persistence;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

import com.softtek.models.entity.Producto;

@RepositoryRestResource(collectionResourceRel = "productos", path = "productos")
public interface ProductosDAO extends CrudRepository<Producto, Long>{

}
