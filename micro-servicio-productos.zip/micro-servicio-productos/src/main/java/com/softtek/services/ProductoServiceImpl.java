package com.softtek.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.softtek.models.entity.Producto;
import com.softtek.persistence.ProductosDAO;

@Service
public class ProductoServiceImpl implements IProductoService{
	
	@Autowired
	private ProductosDAO productosDAO;

	@Override
	public List<Producto> findAll() {
		return (List<Producto>) productosDAO.findAll();
	}

	@Override
	public Producto findById(Long id) {
		return productosDAO.findById(id).orElse(new Producto());
	}

}
